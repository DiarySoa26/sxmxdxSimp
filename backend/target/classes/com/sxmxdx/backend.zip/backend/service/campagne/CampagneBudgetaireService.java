package com.sxmxdx.backend.service.campagne;

import com.sxmxdx.backend.dto.campagne.*;
import com.sxmxdx.backend.entity.campagne.*;
import com.sxmxdx.backend.repository.campagne.*;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.*;
import java.util.*;

@Service
public class CampagneBudgetaireService {

    private final CampagneBudgetaireRepository campagnes;
    private final JalonBudgetaireRepository jalons;

    public CampagneBudgetaireService(
        CampagneBudgetaireRepository campagnes,
        JalonBudgetaireRepository jalons
    ) {
        this.campagnes = campagnes;
        this.jalons = jalons;
    }

    private ResponseStatusException erreur(HttpStatus statut, String message) {
        return new ResponseStatusException(statut, message);
    }

    private CampagneBudgetaire trouver(Long id) {
        return campagnes.findById(id).orElseThrow(() ->
            erreur(HttpStatus.NOT_FOUND, "Campagne introuvable")
        );
    }

    private void verifierModifiable(CampagneBudgetaire c) {
        if ("TERMINEE".equals(c.getStatut()) || "ANNULEE".equals(c.getStatut()))
            throw erreur(HttpStatus.CONFLICT, "Campagne non modifiable");
    }

    private void valider(CampagneRequest r) {
        if (r == null || r.getNom() == null || r.getNom().isBlank()
            || r.getExerciceId() == null
            || r.getDateDebut() == null || r.getDateFin() == null
            || r.getDateImportation() == null || r.getDateGeneration() == null
            || r.getDateVerification() == null || r.getDateCloture() == null)
            throw erreur(HttpStatus.BAD_REQUEST, "Informations incomplètes");

        LocalDate precedente = r.getDateDebut();
        for (LocalDate date : List.of(
            r.getDateImportation(), r.getDateGeneration(),
            r.getDateVerification(), r.getDateCloture()
        )) {
            if (date.isBefore(precedente) || date.isAfter(r.getDateFin()))
                throw erreur(HttpStatus.BAD_REQUEST, "Dates de planification invalides");
            precedente = date;
        }
    }

    private void ajouterJalon(Long campagneId, String nom,
                              String code, int ordre, LocalDate date) {
        JalonBudgetaire j = new JalonBudgetaire();
        j.setCampagneId(campagneId);
        j.setNom(nom);
        j.setCode(code);
        j.setOrdre(ordre);
        j.setDateLimite(date);
        j.setStatut("EN_ATTENTE");
        jalons.save(j);
    }

    @Transactional
    public CampagneBudgetaire creer(CampagneRequest r) {
        valider(r);

        CampagneBudgetaire c = new CampagneBudgetaire();
        c.setNom(r.getNom());
        c.setExerciceId(r.getExerciceId());
        c.setDateDebut(r.getDateDebut());
        c.setDateFin(r.getDateFin());
        c.setStatut("PLANIFIEE");
        c = campagnes.save(c);

        ajouterJalon(c.getId(), "Importation", "IMPORTATION", 1, r.getDateImportation());
        ajouterJalon(c.getId(), "Génération", "GENERATION", 2, r.getDateGeneration());
        ajouterJalon(c.getId(), "Vérification", "VERIFICATION", 3, r.getDateVerification());
        ajouterJalon(c.getId(), "Clôture", "CLOTURE", 4, r.getDateCloture());

        return c;
    }

    public List<CampagneBudgetaire> lister() {
        return campagnes.findAllByOrderByDateDebutDesc();
    }

    public Map<String, Object> details(Long id) {
        CampagneBudgetaire c = trouver(id);
        List<JalonBudgetaire> liste = jalons.findByCampagneIdOrderByOrdreAsc(id);

        long termines = liste.stream()
            .filter(j -> "TERMINE".equals(j.getStatut())).count();

        long retards = liste.stream()
            .filter(j -> !"TERMINE".equals(j.getStatut()))
            .filter(j -> j.getDateLimite().isBefore(LocalDate.now())).count();

        double progression = liste.isEmpty() ? 0 :
            Math.round(termines * 10000.0 / liste.size()) / 100.0;

        Map<String, Object> resultat = new LinkedHashMap<>();
        resultat.put("campagne", c);
        resultat.put("jalons", liste);
        resultat.put("totalJalons", liste.size());
        resultat.put("jalonsTermines", termines);
        resultat.put("jalonsEnRetard", retards);
        resultat.put("progression", progression);

        return resultat;
    }

    @Transactional
    public CampagneBudgetaire modifier(Long id, CampagneRequest r) {
        valider(r);
        CampagneBudgetaire c = trouver(id);
        verifierModifiable(c);

        if (!c.getExerciceId().equals(r.getExerciceId()))
            throw erreur(HttpStatus.CONFLICT, "Impossible de changer l'exercice d'une campagne");

        c.setNom(r.getNom());
        c.setDateDebut(r.getDateDebut());
        c.setDateFin(r.getDateFin());

        Map<String, LocalDate> dates = Map.of(
            "IMPORTATION", r.getDateImportation(),
            "GENERATION", r.getDateGeneration(),
            "VERIFICATION", r.getDateVerification(),
            "CLOTURE", r.getDateCloture()
        );

        for (JalonBudgetaire j : jalons.findByCampagneIdOrderByOrdreAsc(id)) {
            LocalDate date = dates.get(j.getCode());
            if (date != null) j.setDateLimite(date);
        }

        return campagnes.save(c);
    }

    @Transactional
    public JalonBudgetaire modifierJalon(Long id, Long jalonId, JalonRequest r) {
        CampagneBudgetaire c = trouver(id);
        verifierModifiable(c);

        JalonBudgetaire j = jalons.findById(jalonId).orElseThrow(() ->
            erreur(HttpStatus.NOT_FOUND, "Jalon introuvable")
        );

        if (!id.equals(j.getCampagneId()))
            throw erreur(HttpStatus.NOT_FOUND, "Jalon hors campagne");

        if (r == null || r.getDateLimite() == null
            || r.getDateLimite().isBefore(c.getDateDebut())
            || r.getDateLimite().isAfter(c.getDateFin()))
            throw erreur(HttpStatus.BAD_REQUEST, "Date limite invalide");

        List<JalonBudgetaire> liste = jalons.findByCampagneIdOrderByOrdreAsc(id);
        for (JalonBudgetaire autre : liste) {
            if (autre.getId().equals(jalonId)) continue;
            if (autre.getOrdre() < j.getOrdre()
                && autre.getDateLimite().isAfter(r.getDateLimite()))
                throw erreur(HttpStatus.BAD_REQUEST, "Date antérieure au jalon précédent");
            if (autre.getOrdre() > j.getOrdre()
                && autre.getDateLimite().isBefore(r.getDateLimite()))
                throw erreur(HttpStatus.BAD_REQUEST, "Date postérieure au jalon suivant");
        }

        j.setDateLimite(r.getDateLimite());
        return jalons.save(j);
    }

    @Transactional
    public JalonBudgetaire terminerJalon(Long id, Long jalonId) {
        CampagneBudgetaire c = trouver(id);
        verifierModifiable(c);

        JalonBudgetaire j = jalons.findById(jalonId).orElseThrow(() ->
            erreur(HttpStatus.NOT_FOUND, "Jalon introuvable")
        );

        if (!id.equals(j.getCampagneId()))
            throw erreur(HttpStatus.NOT_FOUND, "Jalon hors campagne");

        if (!"VERIFICATION".equals(j.getCode()))
            throw erreur(HttpStatus.CONFLICT, "Ce jalon n'est pas validable manuellement");

        if (!"TERMINE".equals(j.getStatut())) {
            j.setStatut("TERMINE");
            j.setDateRealisation(LocalDateTime.now());
        }

        if ("PLANIFIEE".equals(c.getStatut())) {
            c.setStatut("EN_COURS");
            campagnes.save(c);
        }

        return jalons.save(j);
    }

    @Transactional
    public CampagneBudgetaire cloturer(Long id) {
        CampagneBudgetaire c = trouver(id);
        verifierModifiable(c);

        JalonBudgetaire j = jalons.findByCampagneIdAndCode(id, "CLOTURE")
            .orElseThrow(() ->
                erreur(HttpStatus.NOT_FOUND, "Jalon de clôture introuvable")
            );

        j.setStatut("TERMINE");
        if (j.getDateRealisation() == null)
            j.setDateRealisation(LocalDateTime.now());

        jalons.save(j);
        c.setStatut("TERMINEE");
        return campagnes.save(c);
    }
}