import traceback

from pipeline.budget.generer_budget import generer_budget


def executer_budget():
    """
    Workflow principal de génération du budget.

    Flux :
        generer_budget.py
            ↓
        moteur_regles.py
            ↓
        budget_mensuel
            ↓
        budget annuel
            ↓
        PostgreSQL
    """

    print("=" * 70)
    print("WORKFLOW - GENERATION DU BUDGET")
    print("=" * 70)

    try:
        # ==========================================================
        # ETAPE 1 : GENERATION DU BUDGET
        # ==========================================================

        print("\n[1/1] Génération du budget...")

        resultat = generer_budget()

        print("[OK] Budget généré avec succès.")

        return {
            "success": True,
            "message": "Budget généré avec succès.",
            "resultat": resultat,
        }

    except Exception as exc:

        print("\n[ERREUR] Génération du budget impossible.")
        traceback.print_exc()

        return {
            "success": False,
            "message": "La génération du budget a échoué.",
            "error": str(exc),
        }


# ==============================================================
# EXECUTION DIRECTE
# ==============================================================

if __name__ == "__main__":

    resultat = executer_budget()

    print("\n" + "=" * 70)
    print("RESULTAT DU WORKFLOW")
    print("=" * 70)

    print(resultat)